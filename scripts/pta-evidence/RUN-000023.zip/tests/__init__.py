# tests/__init__.py
"""
Test package initialization for Mobile Money Hub API.
This file makes the tests directory a Python package.
All tests are located in test_api.py and other test modules.
"""