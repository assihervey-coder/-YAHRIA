import pytest
from fastapi.testclient import TestClient
from unittest.mock import patch, MagicMock
from main import app

client = TestClient(app)

def test_health_check():
    """Test the health check endpoint."""
    response = client.get("/health")
    assert response.status_code == 200
    assert response.json()["status"] == "healthy"
    assert "timestamp" in response.json()
    assert "service" in response.json()

def test_list_gateways():
    """Test the gateways list endpoint."""
    response = client.get("/gateways")
    assert response.status_code == 200
    gateways = response.json()
    assert len(gateways) == 2
    assert gateways[0]["name"] == "NotchPay"
    assert gateways[1]["name"] == "PesaPal"
    assert "operators" in gateways[0]
    assert "status" in gateways[0]

@patch("gateways.get_gateway")
def test_initiate_payment_success(mock_get_gateway):
    """Test successful payment initiation."""
    # Mock the gateway
    mock_gateway = MagicMock()
    mock_gateway.initiate_payment.return_value = {
        "payment_id": "pay_12345",
        "gateway": "NotchPay",
        "status": "pending",
        "message": "Payment initiated successfully",
        "redirect_url": "https://notchpay.com/pay/pay_12345"
    }
    mock_get_gateway.return_value = mock_gateway
    
    # Make request
    payment_data = {
        "operator": "MTN",
        "amount": 1000.0,
        "currency": "XOF",
        "reference": "ref_12345"
    }
    response = client.post("/payments/initiate", json=payment_data)
    
    # Verify
    assert response.status_code == 201
    assert response.json()["payment_id"] == "pay_12345"
    assert response.json()["gateway"] == "NotchPay"
    assert response.json()["status"] == "pending"
    assert response.json()["redirect_url"] == "https://notchpay.com/pay/pay_12345"
    
    # Verify gateway was called correctly
    mock_get_gateway.assert_called_once_with("MTN")
    mock_gateway.initiate_payment.assert_called_once_with(
        amount=1000.0,
        currency="XOF",
        reference="ref_12345"
    )

@patch("gateways.get_gateway")
def test_initiate_payment_failure(mock_get_gateway):
    """Test payment initiation with gateway failure."""
    # Mock the gateway to raise an exception
    mock_gateway = MagicMock()
    mock_gateway.initiate_payment.side_effect = Exception("Gateway unavailable")
    mock_get_gateway.return_value = mock_gateway
    
    # Make request
    payment_data = {
        "operator": "MTN",
        "amount": 1000.0,
        "currency": "XOF",
        "reference": "ref_12345"
    }
    response = client.post("/payments/initiate", json=payment_data)
    
    # Verify
    assert response.status_code == 500
    assert response.json()["detail"] == "Gateway unavailable"

@patch("security.verify_webhook_signature")
def test_webhook_handler_success(mock_verify_signature):
    """Test successful webhook handling with valid signature."""
    # Mock signature verification
    mock_verify_signature.return_value = True
    
    # Mock webhook payload
    webhook_payload = {
        "payment_id": "pay_12345",
        "status": "completed",
        "amount": 1000.0
    }
    
    # Make request with signature header
    headers = {"X-Webhook-Signature": "sha256=hmac_signature"}
    response = client.post("/webhooks/NotchPay", json=webhook_payload, headers=headers)
    
    # Verify
    assert response.status_code == 200
    assert response.json()["status"] == "received"
    assert response.json()["message"] == "Webhook processed successfully"
    
    # Verify signature was checked
    mock_verify_signature.assert_called_once()
    args, kwargs = mock_verify_signature.call_args
    assert args[0] == b'{"payment_id": "pay_12345", "status": "completed", "amount": 1000.0}'  # raw body
    assert args[1] == "sha256=hmac_signature"
    assert "SECRET_KEY" in kwargs

def test_webhook_handler_missing_signature():
    """Test webhook handling with missing signature."""
    # Make request without signature header
    webhook_payload = {
        "payment_id": "pay_12345",
        "status": "completed",
        "amount": 1000.0
    }
    response = client.post("/webhooks/NotchPay", json=webhook_payload)
    
    # Verify
    assert response.status_code == 400
    assert response.json()["detail"] == "Missing signature header"

@patch("security.verify_webhook_signature")
def test_webhook_handler_invalid_signature(mock_verify_signature):
    """Test webhook handling with invalid signature."""
    # Mock signature verification to return False
    mock_verify_signature.return_value = False
    
    # Mock webhook payload
    webhook_payload = {
        "payment_id": "pay_12345",
        "status": "completed",
        "amount": 1000.0
    }
    
    # Make request with signature header
    headers = {"X-Webhook-Signature": "sha256=invalid_signature"}
    response = client.post("/webhooks/NotchPay", json=webhook_payload, headers=headers)
    
    # Verify
    assert response.status_code == 401
    assert response.json()["detail"] == "Invalid signature"