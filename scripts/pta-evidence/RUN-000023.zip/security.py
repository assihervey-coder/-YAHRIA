import hashlib
import hmac
import json
import time
from typing import Dict, Any

from config import SECRET_KEY


def create_token(payload: Dict[str, Any]) -> str:
    """
    Create a JWT-like token with the given payload.
    Note: This is a simplified version for demonstration.
    In production, use a proper JWT library like PyJWT.
    """
    header = {"alg": "HS256", "typ": "JWT"}
    header_encoded = _base64url_encode(json.dumps(header).encode('utf-8'))
    payload_encoded = _base64url_encode(json.dumps(payload).encode('utf-8'))
    
    signature_input = f"{header_encoded}.{payload_encoded}".encode('utf-8')
    signature = hmac.new(SECRET_KEY.encode('utf-8'), signature_input, hashlib.sha256).digest()
    signature_encoded = _base64url_encode(signature)
    
    return f"{header_encoded}.{payload_encoded}.{signature_encoded}"


def verify_webhook_signature(raw_body: bytes, signature: str, secret: str) -> bool:
    """
    Verify the webhook signature using HMAC-SHA256.
    Uses hmac.compare_digest for constant-time comparison.
    """
    expected_signature = hmac.new(
        secret.encode('utf-8'),
        raw_body,
        hashlib.sha256
    ).hexdigest()
    
    return hmac.compare_digest(expected_signature, signature)


def _base64url_encode(data: bytes) -> str:
    """
    Helper function for base64url encoding without padding.
    """
    import base64
    return base64.urlsafe_b64encode(data).decode('utf-8').rstrip('=')