from pydantic import BaseModel


class PaymentInitRequest(BaseModel):
    operator: str
    amount: float
    currency: str = "XOF"
    reference: str = ""


class WebhookAck(BaseModel):
    status: str
    message: str