from fastapi import FastAPI, HTTPException, Request, status
from fastapi.responses import JSONResponse
import hmac
import hashlib
from datetime import datetime, timedelta
import os

from config import SECRET_KEY, HUB_NAME
from models import PaymentInitRequest, WebhookAck
from schemas import PaymentInitResponse, GatewayInfo
from gateways import get_gateway
from security import verify_webhook_signature

app = FastAPI(title="Mobile Money Hub")


@app.get("/health", status_code=status.HTTP_200_OK)
async def health_check():
    return {"status": "healthy", "timestamp": datetime.utcnow().isoformat(), "service": HUB_NAME}


@app.get("/gateways", status_code=status.HTTP_200_OK)
async def list_gateways():
    """
    Returns a list of configured payment gateways.
    """
    gateways = [
        {"name": "NotchPay", "operators": ["MTN", "Orange"], "status": "active"},
        {"name": "PesaPal", "operators": ["MTN", "Orange", "Airtel"], "status": "active"},
    ]
    return gateways


@app.post("/payments/initiate", response_model=PaymentInitResponse, status_code=status.HTTP_201_CREATED)
async def initiate_payment(payment_request: PaymentInitRequest):
    """
    Initiate a payment through the appropriate gateway based on the operator.
    """
    try:
        gateway = get_gateway(payment_request.operator)
        payment_data = await gateway.initiate_payment(
            amount=payment_request.amount,
            currency=payment_request.currency,
            reference=payment_request.reference
        )
        
        return PaymentInitResponse(
            payment_id=payment_data.get("payment_id"),
            gateway=payment_data.get("gateway"),
            status=payment_data.get("status"),
            message=payment_data.get("message"),
            redirect_url=payment_data.get("redirect_url")
        )
    except Exception as e:
        raise HTTPException(status_code=status.HTTP_500_INTERNAL_SERVER_ERROR, detail=str(e))


@app.post("/webhooks/{gateway}", status_code=status.HTTP_200_OK)
async def webhook_handler(gateway: str, request: Request):
    """
    Handle webhooks from payment gateways with signature verification.
    """
    try:
        raw_body = await request.body()
        signature = request.headers.get("X-Webhook-Signature")
        
        if not signature:
            raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail="Missing signature header")
        
        if not verify_webhook_signature(raw_body, signature, SECRET_KEY):
            raise HTTPException(status_code=status.HTTP_401_UNAUTHORIZED, detail="Invalid signature")
        
        # Process the webhook payload here
        # This would typically involve updating payment status in the database
        payload = await request.json()
        
        # Return acknowledgment
        return WebhookAck(status="received", message="Webhook processed successfully")
        
    except Exception as e:
        raise HTTPException(status_code=status.HTTP_500_INTERNAL_SERVER_ERROR, detail=str(e))


if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="0.0.0.0", port=8000)