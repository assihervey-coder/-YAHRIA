from typing import Dict, Any
import logging

from security import verify_webhook_signature
from models import WebhookAck
from gateways.base import BaseGateway
from gateways import get_gateway

logger = logging.getLogger(__name__)

def process_webhook(gateway_name: str, raw_body: bytes, signature: str, config: Dict[str, Any]) -> WebhookAck:
    """
    Process a webhook from a specific gateway after verifying its signature.
    
    Args:
        gateway_name: Name of the gateway (e.g., "notchpay", "pesapal")
        raw_body: Raw request body as bytes
        signature: Signature from the request header
        config: Configuration dictionary containing gateway settings
        
    Returns:
        WebhookAck response with appropriate status and message
        
    Raises:
        ValueError: If signature verification fails or gateway is unsupported
    """
    # Get the gateway configuration
    gateway_config = {}
    if gateway_name.lower() == "notchpay":
        gateway_config = {
            "base_url": config.get("NOTCHPAY_BASE_URL"),
            "api_key": config.get("NOTCHPAY_API_KEY")
        }
    elif gateway_name.lower() == "pesapal":
        gateway_config = {
            "base_url": config.get("PESAPAL_BASE_URL"),
            "consumer_key": config.get("PESAPAL_CONSUMER_KEY"),
            "consumer_secret": config.get("PESAPAL_CONSUMER_SECRET")
        }
    else:
        raise ValueError(f"Unsupported gateway: {gateway_name}")
    
    # Get the appropriate gateway instance to extract the secret
    gateway = get_gateway(gateway_name.lower(), gateway_config)
    if not hasattr(gateway, 'webhook_secret'):
        raise ValueError(f"Gateway {gateway_name} does not support webhook verification")
    
    # Verify the signature
    if not verify_webhook_signature(raw_body, signature, gateway.webhook_secret):
        logger.warning(f"Invalid webhook signature for gateway: {gateway_name}")
        return WebhookAck(status="error", message="Invalid signature")
    
    # Parse the webhook data (implementation would depend on actual gateway format)
    try:
        # In a real implementation, you would parse the raw_body according to the gateway's format
        # For now, we'll just acknowledge receipt
        webhook_data = raw_body.decode('utf-8')
        logger.info(f"Received valid webhook from {gateway_name}: {webhook_data}")
        
        # Process the webhook data based on gateway type
        # This would typically involve updating payment status in your database
        if gateway_name.lower() == "notchpay":
            # NotchPay specific processing
            pass
        elif gateway_name.lower() == "pesapal":
            # PesaPal specific processing
            pass
            
        return WebhookAck(status="success", message="Webhook processed successfully")
        
    except Exception as e:
        logger.error(f"Error processing webhook from {gateway_name}: {str(e)}")
        return WebhookAck(status="error", message=f"Processing error: {str(e)}")