from .notchpay import NotchPayGateway
from .pesapal import PesaPalGateway

def get_gateway(operator: str, config: dict):
    """Factory function to create appropriate gateway instance based on operator.
    
    Args:
        operator: Mobile money operator name (e.g., "notchpay", "pesapal")
        config: Configuration dictionary for the gateway
        
    Returns:
        Appropriate gateway instance
        
    Raises:
        ValueError: If operator is not supported
    """
    operator = operator.lower()
    
    if operator == "notchpay":
        return NotchPayGateway(config)
    elif operator == "pesapal":
        return PesaPalGateway(config)
    else:
        raise ValueError(f"Unsupported operator: {operator}")