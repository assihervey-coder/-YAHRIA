from abc import ABC, abstractmethod
from typing import Dict, Any, Optional

class BaseGateway(ABC):
    """Abstract base class for payment gateway providers."""
    
    def __init__(self, config: Dict[str, Any]):
        """Initialize the gateway with configuration.
        
        Args:
            config: Configuration dictionary specific to the gateway
        """
        self.config = config
    
    @abstractmethod
    def initiate_payment(self, amount: float, currency: str, reference: str, **kwargs) -> Dict[str, Any]:
        """Initiate a payment transaction.
        
        Args:
            amount: Payment amount
            currency: Currency code (e.g., "XOF")
            reference: Unique payment reference
            **kwargs: Additional parameters specific to the gateway
            
        Returns:
            Dictionary containing payment initiation response
        """
        pass
    
    @abstractmethod
    def verify_webhook(self, raw_body: bytes, signature: str) -> bool:
        """Verify the authenticity of a webhook notification.
        
        Args:
            raw_body: Raw request body bytes
            signature: Signature to verify against
            
        Returns:
            True if verification succeeds, False otherwise
        """
        pass
    
    @abstractmethod
    def get_payment_status(self, payment_id: str) -> Dict[str, Any]:
        """Check the status of a payment transaction.
        
        Args:
            payment_id: Payment identifier from the gateway
            
        Returns:
            Dictionary containing payment status information
        """
        pass
    
    def get_name(self) -> str:
        """Get the name of the gateway.
        
        Returns:
            Gateway name
        """
        return self.__class__.__name__.lower().replace('gateway', '')