from typing import Dict, Any
import hashlib
import hmac
import base64
import json
import requests
from datetime import datetime, timedelta
from .base import BaseGateway

class PesaPalGateway(BaseGateway):
    """PesaPal payment gateway implementation."""
    
    def __init__(self, config: Dict[str, Any]):
        """Initialize the PesaPal gateway with configuration.
        
        Args:
            config: Configuration dictionary containing PesaPal credentials
        """
        super().__init__(config)
        self.consumer_key = self.config.get('consumer_key')
        self.consumer_secret = self.config.get('consumer_secret')
        self.base_url = self.config.get('base_url')
        
        # Get access token
        self.access_token = self._get_access_token()
    
    def _get_access_token(self) -> str:
        """Get PesaPal OAuth access token.
        
        Returns:
            OAuth access token string
        """
        url = f"{self.base_url}/oauth/token"
        headers = {
            'Content-Type': 'application/json',
            'Accept': 'application/json'
        }
        
        # Basic auth with consumer key and secret
        auth_string = f"{self.consumer_key}:{self.consumer_secret}"
        auth_bytes = auth_string.encode('ascii')
        auth_header = base64.b64encode(auth_bytes).decode('ascii')
        
        headers['Authorization'] = f'Basic {auth_header}'
        
        payload = {
            'grant_type': 'client_credentials'
        }
        
        response = requests.post(url, headers=headers, json=payload)
        response.raise_for_status()
        
        return response.json()['access_token']
    
    def initiate_payment(self, amount: float, currency: str, reference: str, **kwargs) -> Dict[str, Any]:
        """Initiate a payment with PesaPal.
        
        Args:
            amount: Payment amount
            currency: Currency code (e.g., "XOF")
            reference: Unique payment reference
            **kwargs: Additional parameters (phone, email, etc.)
            
        Returns:
            Dictionary containing payment initiation response
        """
        url = f"{self.base_url}/transactions/submitorder"
        headers = {
            'Content-Type': 'application/json',
            'Accept': 'application/json',
            'Authorization': f'Bearer {self.access_token}'
        }
        
        # Prepare payment request
        payment_request = {
            'id': reference,
            'currency': currency,
            'amount': amount,
            'description': f"Payment {reference}",
            'callback_url': kwargs.get('callback_url', ''),
            'notification_id': reference,
            'billing_address': {
                'email_address': kwargs.get('email', ''),
                'phone_number': kwargs.get('phone', ''),
                'country': kwargs.get('country', 'KE')
            }
        }
        
        response = requests.post(url, headers=headers, json=payment_request)
        response.raise_for_status()
        
        return response.json()
    
    def verify_webhook(self, raw_body: bytes, signature: str) -> bool:
        """Verify PesaPal webhook signature.
        
        Args:
            raw_body: Raw request body bytes
            signature: Signature to verify against
            
        Returns:
            True if verification succeeds, False otherwise
        """
        # PesaPal uses HMAC-SHA256 with consumer secret as key
        computed_signature = hmac.new(
            self.consumer_secret.encode('utf-8'),
            raw_body,
            hashlib.sha256
        ).hexdigest()
        
        # Compare signatures in constant time
        return hmac.compare_digest(computed_signature, signature)
    
    def get_payment_status(self, payment_id: str) -> Dict[str, Any]:
        """Check the status of a PesaPal payment.
        
        Args:
            payment_id: Payment identifier from PesaPal
            
        Returns:
            Dictionary containing payment status information
        """
        url = f"{self.base_url}/transactions/transactionstatus"
        headers = {
            'Content-Type': 'application/json',
            'Accept': 'application/json',
            'Authorization': f'Bearer {self.access_token}'
        }
        
        payload = {
            'merchant_reference': payment_id
        }
        
        response = requests.post(url, headers=headers, json=payload)
        response.raise_for_status()
        
        return response.json()