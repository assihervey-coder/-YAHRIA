from typing import Dict, Any
import hashlib
import hmac
import requests
import json
from datetime import datetime, timedelta
from .base import BaseGateway

class NotchPayGateway(BaseGateway):
    """NotchPay payment gateway implementation."""
    
    def __init__(self, config: Dict[str, Any]):
        """Initialize the NotchPay gateway with configuration.
        
        Args:
            config: Configuration dictionary containing API key and base URL
        """
        super().__init__(config)
        self.api_key = config.get("api_key")
        self.base_url = config.get("base_url")
    
    def initiate_payment(self, amount: float, currency: str, reference: str, **kwargs) -> Dict[str, Any]:
        """Initiate a payment transaction with NotchPay.
        
        Args:
            amount: Payment amount
            currency: Currency code (e.g., "XOF")
            reference: Unique payment reference
            **kwargs: Additional parameters
            
        Returns:
            Dictionary containing payment initiation response
        """
        url = f"{self.base_url}/payments"
        
        payload = {
            "amount": amount,
            "currency": currency,
            "reference": reference,
            "callback_url": kwargs.get("callback_url"),
            "customer": kwargs.get("customer", {})
        }
        
        headers = {
            "Content-Type": "application/json",
            "Authorization": f"Bearer {self.api_key}"
        }
        
        response = requests.post(url, json=payload, headers=headers)
        
        if response.status_code == 201:
            return {
                "success": True,
                "payment_id": response.json().get("id"),
                "payment_url": response.json().get("payment_url"),
                "status": response.json().get("status")
            }
        else:
            return {
                "success": False,
                "error": response.json().get("message", "Payment initiation failed")
            }
    
    def verify_webhook(self, raw_body: bytes, signature: str) -> bool:
        """Verify the authenticity of a webhook notification from NotchPay.
        
        Args:
            raw_body: Raw request body bytes
            signature: Signature to verify against
            
        Returns:
            True if verification succeeds, False otherwise
        """
        expected_signature = hmac.new(
            key=self.config.get("secret_key", "").encode(),
            msg=raw_body,
            digestmod=hashlib.sha256
        ).hexdigest()
        
        return hmac.compare_digest(signature, expected_signature)
    
    def get_payment_status(self, payment_id: str) -> Dict[str, Any]:
        """Check the status of a payment transaction with NotchPay.
        
        Args:
            payment_id: Payment identifier from NotchPay
            
        Returns:
            Dictionary containing payment status information
        """
        url = f"{self.base_url}/payments/{payment_id}"
        
        headers = {
            "Content-Type": "application/json",
            "Authorization": f"Bearer {self.api_key}"
        }
        
        response = requests.get(url, headers=headers)
        
        if response.status_code == 200:
            return {
                "success": True,
                "payment_id": payment_id,
                "status": response.json().get("status"),
                "amount": response.json().get("amount"),
                "currency": response.json().get("currency"),
                "created_at": response.json().get("created_at"),
                "updated_at": response.json().get("updated_at")
            }
        else:
            return {
                "success": False,
                "error": response.json().get("message", "Failed to retrieve payment status")
            }