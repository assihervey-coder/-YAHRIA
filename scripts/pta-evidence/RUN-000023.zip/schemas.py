from pydantic import BaseModel, Field
from typing import Optional


class PaymentInitRequest(BaseModel):
    operator: str = Field(..., description="Mobile money operator (e.g., 'MTN', 'Orange')")
    amount: float = Field(..., gt=0, description="Payment amount")
    currency: str = Field("XOF", description="Currency code (default: XOF)")
    reference: str = Field("", description="Optional reference number")


class PaymentInitResponse(BaseModel):
    payment_id: str = Field(..., description="Unique payment identifier")
    gateway: str = Field(..., description="Selected payment gateway")
    status: str = Field(..., description="Payment initiation status")
    message: str = Field(..., description="Response message")
    redirect_url: Optional[str] = Field(None, description="URL for payment completion if required")


class WebhookAck(BaseModel):
    status: str = Field(..., description="Webhook processing status")
    message: str = Field(..., description="Processing message")


class GatewayInfo(BaseModel):
    name: str = Field(..., description="Gateway name")
    operator: str = Field(..., description="Supported operator")
    status: str = Field(..., description="Gateway status")