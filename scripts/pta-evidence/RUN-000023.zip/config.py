import os

HUB_NAME = os.environ.get("HUB_NAME", "Mobile Money Hub")
SECRET_KEY = os.environ.get("HUB_SECRET_KEY", "sandbox-secret-key-change-me")
NOTCHPAY_BASE_URL = os.environ.get("NOTCHPAY_BASE_URL", "https://api.sandbox.notchpay.com")
NOTCHPAY_API_KEY = os.environ.get("NOTCHPAY_API_KEY", "sandbox-notchpay-api-key")
PESAPAL_BASE_URL = os.environ.get("PESAPAL_BASE_URL", "https://api.pesapal.com/v3")
PESAPAL_CONSUMER_KEY = os.environ.get("PESAPAL_CONSUMER_KEY", "sandbox-pesapal-consumer-key")
PESAPAL_CONSUMER_SECRET = os.environ.get("PESAPAL_CONSUMER_SECRET", "sandbox-pesapal-consumer-secret")
WEBHOOK_TOLERANCE_SECONDS = int(os.environ.get("WEBHOOK_TOLERANCE_SECONDS", "300"))