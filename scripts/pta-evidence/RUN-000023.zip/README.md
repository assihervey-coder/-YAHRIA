# Mobile Money Hub API

A unified Mobile Money payment API hub that integrates multiple payment gateways, starting with NotchPay and PesaPal.

## Features

- Unified API for multiple mobile money payment gateways
- Secure webhook handling with HMAC-SHA256 signature verification
- Configurable payment gateways
- Health check endpoints

## Installation

1. Clone the repository:
```bash
git clone <repository-url>
cd mobile-money-hub
```

2. Create and activate a virtual environment:
```bash
python -m venv venv
source venv/bin/activate  # On Windows: venv\Scripts\activate
```

3. Install dependencies:
```bash
pip install -r requirements.txt
```

4. Run the application:
```bash
python main.py
```

The API will be available at `http://localhost:8000`.

## Configuration

The application uses a configuration file (`config.py`) with the following default values:

```python
HUB_NAME = "Mobile Money Hub"
SECRET_KEY = os.environ.get("HUB_SECRET_KEY", "sandbox-secret-key-change-me")
NOTCHPAY_BASE_URL = os.environ.get("NOTCHPAY_BASE_URL", "https://api.notchpay.sandbox.com")
NOTCHPAY_API_KEY = os.environ.get("NOTCHPAY_API_KEY", "notchpay-api-key-sandbox")
PESAPAL_BASE_URL = os.environ.get("PESAPAL_BASE_URL", "https://demo.pesapal.com")
PESAPAL_CONSUMER_KEY = os.environ.get("PESAPAL_CONSUMER_KEY", "pesapal-consumer-key-sandbox")
PESAPAL_CONSUMER_SECRET = os.environ.get("PESAPAL_CONSUMER_SECRET", "pesapal-consumer-secret-sandbox")
WEBHOOK_TOLERANCE_SECONDS = os.environ.get("WEBHOOK_TOLERANCE_SECONDS", 300)
```

You can override any of these values by setting the corresponding environment variable.

## API Endpoints

### Health Check

- **GET** `/health`
  - Returns a 200 OK status if the service is running
  - Response: `{"status": "ok"}`

### Gateway Information

- **GET** `/gateways`
  - Returns a list of configured payment gateways
  - Response: `["notchpay", "pesapal"]`

### Initiate Payment

- **POST** `/payments/initiate`
  - Initiates a payment through the appropriate gateway based on the operator
  - Request body:
    ```json
    {
      "operator": "mtn",
      "amount": 1000.0,
      "currency": "XOF",
      "reference": "payment-ref-123"
    }
    ```
  - Response: Payment initiation response from the selected gateway

### Webhooks

- **POST** `/webhooks/{gateway}`
  - Handles webhook notifications from payment gateways
  - The gateway name in the URL must match one of the configured gateways
  - The request includes an `X-Webhook-Signature` header with the HMAC-SHA256 signature
  - The application verifies the signature before processing the webhook
  - Request body:
    ```json
    {
      "status": "completed",
      "message": "Payment successful"
    }
    ```
  - Response: `{"status": "acknowledged"}`

## Security

### Webhook Signature Verification

The application verifies webhook signatures using HMAC-SHA256 to ensure the requests are legitimate:

1. The gateway computes a signature of the raw request body using the shared secret
2. The signature is included in the `X-Webhook-Signature` header
3. The application recomputes the signature and compares it with the received signature using a constant-time comparison to prevent timing attacks

### Token Creation

The `security.py` module provides a `create_token` function for generating authentication tokens when needed.

## Testing

Run the test suite:
```bash
python -m pytest tests/
```

## Project Structure

```
mobile-money-hub/
├── main.py              # FastAPI application entry point
├── config.py            # Configuration settings
├── models.py            # Pydantic models
├── schemas.py           # Request/response schemas
├── security.py          # Security utilities
├── webhooks.py          # Webhook handling logic
├── gateways/            # Payment gateway implementations
│   ├── __init__.py
│   ├── base.py          # Base gateway class
│   ├── notchpay.py      # NotchPay implementation
│   └── pesapal.py       # PesaPal implementation
├── tests/               # Test suite
│   ├── __init__.py
│   └── test_api.py
├── requirements.txt     # Python dependencies
└── README.md            # This file
```

## Adding New Gateways

To add a new payment gateway:

1. Create a new module in the `gateways/` directory
2. Implement the `BaseGateway` interface
3. Add the new gateway to the gateway factory in `main.py`
4. Update the configuration in `config.py` if needed
5. Add tests for the new gateway

## License

[Add your license information here]